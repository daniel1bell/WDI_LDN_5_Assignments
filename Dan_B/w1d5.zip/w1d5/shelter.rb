class Shelter

  attr_accessor :name, :animals, :clients

  def initialize(name)
    @name = name
    @animals = {}
    @clients = {}

  end

  def list_available_pets
    animals.keys.join(', ')
  end

  def list_prospects
    clients.keys.join(', ')
  end

  def add_prospect
  print "What is the prospect name? "
  prospect_name = gets.chomp.capitalize
  print "What is the prospect's phone number"
  prospect_phone = gets.chomp

  clients[prospect_name] = Person.new(prospect_name, prospect_phone)
  puts "Thanks for adding #{prospect_name} as a new prospect."

  end

  # def list_clients

  # end

end